context("Check checker functions")

test_that("check_prob", {
  
  expect_true(check_prob(0.5))
})
